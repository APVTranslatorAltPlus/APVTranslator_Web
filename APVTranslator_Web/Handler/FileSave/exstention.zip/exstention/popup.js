document.addEventListener("DOMContentLoaded", function(event) {
    /*var listImg=$('img');
    for (var i = 0; i < listImg.length; i++) {
      console.log($(listImg[i]).attr('src'));
      $('#list-img').append( "<li><img src='"+$(listImg[i]).attr('src')+"'></img></li>" );
    }*/
    $('.html5-video-container').before("<p>Hai Phút Rưỡi</p>");
});