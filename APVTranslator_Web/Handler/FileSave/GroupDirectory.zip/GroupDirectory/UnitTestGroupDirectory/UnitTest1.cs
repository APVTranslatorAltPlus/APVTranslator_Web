﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GroupDirectory.Combine;
using System.Collections.Generic;
using GroupDirectory;

namespace UnitTestGroupDirectory
{
    [TestClass]
    public class UnitTestCombineHelper
    {
        [TestMethod]
        public void TestGetListPathInput()
        {
            String input = "rootuploaded\\samplefolder\\1232_2342.jpg\n" +
                            "rootuploaded\\samplefolder\\1232_234234_1.jpg\n" +
                            "rootuploaded\\samplefolder\\1232_234234_2.bmp\n" +
                            "rootuploaded\\file­-5.txt\n" +
                            "rootuploaded\\file-­67.txt\n" +
                            "rootuploaded\\file­a.txt\n" +
                            "rootuploaded\\file1.txt\n" +
                            "rootuploaded\\file2.txt\n" +
                            "rootuploaded\\file5.txt\n" +
                            "rootuploaded\\filea.txt\n" +
                            "rootuploaded\\file_sample.txt\n" +
                            "rootuploaded\\file_sample_a.txt\n";
            Form1 oForm1 = new Form1();
            List<String> lstResult = oForm1.GetListPathInput(input);
            List<String> lstTextWant = new List<string>() { "rootuploaded\\samplefolder\\1232_2342.jpg",
                                                            "rootuploaded\\samplefolder\\1232_234234_1.jpg",
                                                            "rootuploaded\\samplefolder\\1232_234234_2.bmp",
                                                            "rootuploaded\\file­-5.txt",
                                                            "rootuploaded\\file-­67.txt",
                                                            "rootuploaded\\file­a.txt",
                                                            "rootuploaded\\file1.txt",
                                                            "rootuploaded\\file2.txt",
                                                            "rootuploaded\\file5.txt",
                                                            "rootuploaded\\filea.txt",
                                                            "rootuploaded\\file_sample.txt",
                                                            "rootuploaded\\file_sample_a.txt"};
            Boolean bResult = true;
            if (lstResult.Count == lstTextWant.Count)
            {
                for (int i = 0; i < lstResult.Count; i++)
                {
                    if (lstResult[i] != lstTextWant[i])
                    {
                        bResult = false;
                    }
                }
            }
            else
            {
                bResult = false;
            }
            Assert.AreEqual(bResult, true);
        }
        //have 2 path ==
        [TestMethod]
        public void TestGetListPathInput1()
        {
            String input = "rootuploaded\\samplefolder\\1232_2342.jpg\n" +
                            "rootuploaded\\samplefolder\\1232_2342.jpg\n";
            Form1 oForm1 = new Form1();
            List<String> lstResult = oForm1.GetListPathInput(input);
            List<String> lstTextWant = new List<string>() { "rootuploaded\\samplefolder\\1232_2342.jpg"};
            Boolean bResult = true;
            if (lstResult.Count == lstTextWant.Count)
            {
                for (int i = 0; i < lstResult.Count; i++)
                {
                    if (lstResult[i] != lstTextWant[i])
                    {
                        bResult = false;
                    }
                }
            }
            else
            {
                bResult = false;
            }
            Assert.AreEqual(bResult, true);    
        }
        [TestMethod]
        public void TestMovePathToGroupConvention()
        {
            List<String> listPath = new List<string>() { "rootuploaded\\samplefolder\\1232_2342.jpg",
                                                            "rootuploaded\\samplefolder\\1232_234234_1.jpg",
                                                            "rootuploaded\\samplefolder\\1232_234234_2.bmp",
                                                            "rootuploaded\\file-5.txt",
                                                            "rootuploaded\\file-67.txt",
                                                            "rootuploaded\\file­a.txt",
                                                            "rootuploaded\\file1.txt",
                                                            "rootuploaded\\file2.txt",
                                                            "rootuploaded\\file5.txt",
                                                            "rootuploaded\\filea.txt",
                                                            "rootuploaded\\file_sample.txt",
                                                            "rootuploaded\\file_sample_a.txt"};
            CombineHelper oCombineHelper = new CombineHelper(listPath);
            List<String> lstTextResult = oCombineHelper.GetGroupDirectoryTree();
            List<String> lstTextWant = new List<string>() { "rootuploaded\\file_sample.txt\n\trootuploaded\\file_sample_a.txt\n",
                                                            "rootuploaded\\samplefolder\\1232_234234_1.jpg\n\trootuploaded\\samplefolder\\1232_234234_2.bmp\n",
                                                            "rootuploaded\\file-5.txt\n\trootuploaded\\file-67.txt\n",
                                                            "rootuploaded\\file1.txt\n\trootuploaded\\file2.txt\n\trootuploaded\\file5.txt\n",
                                                            "rootuploaded\\samplefolder\\1232_2342.jpg\n\trootuploaded\\file­a.txt\n\trootuploaded\\filea.txt\n"};
            Boolean bResult = true;
            if (lstTextResult.Count == lstTextWant.Count)
            {
                for (int i = 0; i < lstTextResult.Count; i++)
                {
                    if (lstTextResult[i] != lstTextWant[i])
                    {
                        bResult = false;
                    }
                }
            }
            else
            {
                bResult = true;
            }
            Assert.AreEqual(bResult, true);
        }
    }
}
