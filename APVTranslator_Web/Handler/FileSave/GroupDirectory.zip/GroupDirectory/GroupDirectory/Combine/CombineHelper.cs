﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GroupDirectory.Combine
{
    public class CombineHelper
    {
        #region "Declare"
        private List<String> _ListPath = new List<string>();

        private Regex regex1 = new Regex(Constant.regexConvention1);
        private Regex regex2 = new Regex(Constant.regexConvention2);
        private Regex regex3 = new Regex(Constant.regexConvention3);
        private Regex regex4 = new Regex(Constant.regexConvention4);
        private Regex regex5 = new Regex(Constant.regexConvention5);
        private Regex regex6 = new Regex(Constant.regexConvention6);

        private List<Match> _ListMatch1 = new List<Match>();
        private List<Match> _ListMatch2 = new List<Match>();
        private List<Match> _ListMatch3 = new List<Match>();
        private List<Match> _ListMatch4 = new List<Match>();
        private List<Match> _ListMatch5 = new List<Match>();
        private List<Match> _ListMatch6 = new List<Match>();
        private List<Match> _ListPathGrouped = new List<Match>();
        #endregion
        #region "Constructor"
        public CombineHelper(List<String> listPath)
        {
            this._ListPath = listPath;
        }
        #endregion
        #region "Func/Sub"
        /// <summary>
        /// Get List String Did Build to String
        /// </summary>
        public List<String> GetGroupDirectoryTree()
        {
            MovePathToGroupConvention();
            List<List<Match>> lstListGroup = MovePathToGroup();
            List<String> lstStringGroup = BuildToListString(lstListGroup);
            return lstStringGroup;
        }
        /// <summary>
        /// get List ListMatch procces follow rule convention not yet group
        /// </summary>
        public List<List<Match>> GetListPureGroup()
        {
            MovePathToGroupConvention();
            List<List<Match>> lstListMatchGroup = MovePathToGroup();
            return lstListMatchGroup;
        }
        /// <summary>
        /// build list match by rules conventions to list String
        /// </summary>
        /// <param name="lstListGroup"></param>
        private List<string> BuildToListString(List<List<Match>> lstListGroup)
        {
            List<String> lstStringGroup = new List<string>();
            StringBuilder sbResultGroup = new StringBuilder();
            //convert to string
            foreach (List<Match> listGroup in lstListGroup)
            {
                sbResultGroup.Clear();
                foreach (Match item in listGroup)
                {
                    sbResultGroup.Append(item.Value);
                    if (item.Equals(listGroup.Last()))
                    {
                        sbResultGroup.Append("\n");
                    }
                    else
                    {
                        sbResultGroup.Append("\n\t");
                    }
                }
                lstStringGroup.Add(sbResultGroup.ToString());
            }
            List<String> temp = new List<string>(_ListPath);
            _ListPathGrouped = _ListPathGrouped.Distinct().ToList();
            temp.RemoveAll(a => _ListPathGrouped.Any(b => a == b.Value));
            sbResultGroup.Clear();
            foreach (String item in temp)
            {
                sbResultGroup.Append(item);
                if (item.Equals(temp.Last()))
                {
                    sbResultGroup.Append("\n");
                }
                else
                {
                    sbResultGroup.Append("\n\t");
                }

            }
            lstStringGroup.Add(sbResultGroup.ToString());
            return lstStringGroup;
        }
        /// <summary>
        /// step 1 split directory in list path to group follow conventens
        /// </summary>
        /// <returns></returns>
        private List<List<Match>> MovePathToGroup()
        {
            List<List<Match>> lstListGroup = new List<List<Match>>();
            List<Match> listMatchTemp;
            //check rule and 
            List<List<Match>> listListMatch1 = GetListMatch1();
            lstListGroup.AddRange(listListMatch1);
            foreach (List<Match> lstMatch in listListMatch1)
            {
                _ListPathGrouped.AddRange(lstMatch);
            }
            List<List<Match>> listListMatch2 = GetListMatch2();
            lstListGroup.AddRange(listListMatch2);
            foreach (List<Match> lstMatch in listListMatch2)
            {
                _ListPathGrouped.AddRange(lstMatch);
            }
            listMatchTemp = new List<Match>(_ListMatch3);
            foreach (Match match in _ListMatch3)
            {
                var lstBuildGrouped = ProccesingBuildList(listMatchTemp, match);
                lstListGroup.AddRange(lstBuildGrouped);
            }
            listMatchTemp = new List<Match>(_ListMatch4);
            foreach (Match match in _ListMatch4)
            {
                var lstBuildGrouped = ProccesingBuildList(listMatchTemp, match);
                lstListGroup.AddRange(lstBuildGrouped);
            }
            listMatchTemp = new List<Match>(_ListMatch5);
            foreach (Match match in _ListMatch5)
            {
                var lstBuildGrouped = ProccesingBuildList(listMatchTemp, match);
                lstListGroup.AddRange(lstBuildGrouped);
            }
            List<List<Match>> listListMatch6 = GetListMatch6();
            lstListGroup.AddRange(listListMatch6);
            foreach (List<Match> lstMatch in listListMatch6)
            {
                _ListPathGrouped.AddRange(lstMatch);
            }
            return lstListGroup;
        }
        /// <summary>
        /// get List valid convention by Regex Expression
        /// </summary>
        private List<List<Match>> ProccesingBuildList(List<Match> listMatchTemp, Match match)
        {
            List<List<Match>> lstListGroup = new List<List<Match>>();
            List<Match> lstGroup = listMatchTemp.Where(a => a.Groups[1].Value == match.Groups[1].Value && a.Groups[5].Value == match.Groups[5].Value).ToList();
            listMatchTemp.RemoveAll(a => a.Groups[1].Value == match.Groups[1].Value && a.Groups[5].Value == match.Groups[5].Value);
            if (lstGroup.Count >= 2 && lstGroup.Count <= 5)
            {
                lstListGroup.Add(lstGroup);
                _ListPathGrouped.AddRange(lstGroup);
            }
            else if (lstGroup.Count >= 5)
            {
                int count = lstGroup.Count;
                int currentIndex = 0;
                while (count >= 5)
                {
                    var lstThisGroup = lstGroup.Skip(currentIndex).Take(5).ToList();
                    lstListGroup.Add(lstThisGroup);
                    _ListPathGrouped.AddRange(lstThisGroup);
                    currentIndex += 5;
                    count -= 5;
                }
                if (count < 5 && count > 1)
                {
                    var lstThisGroup = lstGroup.Skip(currentIndex).Take(count).ToList();
                    lstListGroup.Add(lstThisGroup);
                    _ListPathGrouped.AddRange(lstThisGroup);
                }
            }
            return lstListGroup;
        }
        #region "Get List valid Conventions"
        /// <summary>
        /// get list group by convention1
        /// </summary>
        private List<List<Match>> GetListMatch1()
        {
            var listMatchTemp = new List<Match>(_ListMatch1);
            List<List<Match>> listListMatch = new List<List<Match>>();
            foreach (var match in _ListMatch1)
            {
                List<Match> lstGroup = listMatchTemp.Where(a => a.Groups[1].Value == match.Groups[1].Value).ToList();
                listMatchTemp.RemoveAll(a => a.Groups[1].Value == match.Groups[1].Value);

                if (lstGroup.Count() >= 2)
                {
                    for (int i = 0; i < lstGroup.Count; i++)
                    {
                        List<Match> lstTemp = new List<Match>();
                        for (int j = i + 1; j < lstGroup.Count; j++)
                        {
                            if (!_ListPathGrouped.Contains(lstGroup[j]) && !_ListPathGrouped.Contains(lstGroup[i]))
                            {
                                bool bResult = CheckRuleConvention1(lstGroup[i].Value, lstGroup[j].Value);
                                if (bResult)
                                {
                                    if (!lstTemp.Contains(lstGroup[i]))
                                    {
                                        lstTemp.Add(lstGroup[i]);
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                    else
                                    {
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                }
                            }
                        }
                        if (lstTemp.Count >= 2 && lstTemp.Count <= 5 && !listListMatch.Contains(lstTemp))
                        {
                            listListMatch.Add(lstTemp);
                            _ListPathGrouped.AddRange(lstTemp);
                        }
                        else if (lstTemp.Count >= 5)
                        {
                            int count = lstTemp.Count;
                            int currentIndex = 0;
                            while (count >= 5)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(5).ToList();
                                listListMatch.Add(lstThisGroup);
                                currentIndex += 5;
                                count -= 5;
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                            if (count < 5 && count > 1)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(count).ToList();
                                listListMatch.Add(lstThisGroup);
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                        }
                    }
                }
            }
            return listListMatch;
        }
        /// <summary>
        /// get list group by convention2
        /// </summary>
        /// <returns></returns>
        private List<List<Match>> GetListMatch2()
        {
            var listMatchTemp = new List<Match>(_ListMatch2);
            List<List<Match>> listListMatch = new List<List<Match>>();
            foreach (var match in _ListMatch2)
            {
                List<Match> lstGroup = listMatchTemp.Where(a => a.Groups[1].Value == match.Groups[1].Value).ToList();
                listMatchTemp.RemoveAll(a => a.Groups[1].Value == match.Groups[1].Value);

                if (lstGroup.Count() >= 2)
                {
                    for (int i = 0; i < lstGroup.Count; i++)
                    {
                        List<Match> lstTemp = new List<Match>();
                        for (int j = i + 1; j < lstGroup.Count; j++)
                        {
                            if (!_ListPathGrouped.Contains(lstGroup[j]) && !_ListPathGrouped.Contains(lstGroup[i]))
                            {
                                bool bResult = CheckRuleConvention2(lstGroup[i].Value, lstGroup[j].Value);
                                if (bResult)
                                {
                                    if (!lstTemp.Contains(lstGroup[i]))
                                    {
                                        lstTemp.Add(lstGroup[i]);
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                    else
                                    {
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                }
                            }
                        }
                        if (lstTemp.Count >= 2 && lstTemp.Count <= 5 && !listListMatch.Contains(lstTemp))
                        {
                            listListMatch.Add(lstTemp);
                            _ListPathGrouped.AddRange(lstTemp);
                        }
                        else if (lstTemp.Count >= 5)
                        {
                            int count = lstTemp.Count;
                            int currentIndex = 0;
                            while (count >= 5)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(5).ToList();
                                listListMatch.Add(lstThisGroup);
                                currentIndex += 5;
                                count -= 5;
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                            if (count < 5 && count > 1)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(count).ToList();
                                listListMatch.Add(lstThisGroup);
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                        }
                    }
                }
            }
            return listListMatch;
        }
        /// <summary>
        /// get list group by convention6
        /// </summary>
        /// <returns></returns>
        private List<List<Match>> GetListMatch6()
        {
            var listMatchTemp = new List<Match>(_ListMatch6);
            List<List<Match>> listListMatch = new List<List<Match>>();
            foreach (var match in _ListMatch6)
            {
                List<Match> lstGroup = listMatchTemp.Where(a => a.Groups[1].Value == match.Groups[1].Value).ToList();
                listMatchTemp.RemoveAll(a => a.Groups[1].Value == match.Groups[1].Value);

                if (lstGroup.Count() >= 2)
                {
                    for (int i = 0; i < lstGroup.Count; i++)
                    {
                        List<Match> lstTemp = new List<Match>();
                        for (int j = i + 1; j < lstGroup.Count; j++)
                        {
                            if (!_ListPathGrouped.Contains(lstGroup[j]) && !_ListPathGrouped.Contains(lstGroup[i]))
                            {
                                bool bResult = CheckRuleConvention6(lstGroup[i].Value, lstGroup[j].Value);
                                if (bResult)
                                {
                                    if (!lstTemp.Contains(lstGroup[i]))
                                    {
                                        lstTemp.Add(lstGroup[i]);
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                    else
                                    {
                                        lstTemp.Add(lstGroup[j]);
                                    }
                                }
                            }
                        }
                        if (lstTemp.Count >= 2 && lstTemp.Count <= 5 && !listListMatch.Contains(lstTemp))
                        {
                            listListMatch.Add(lstTemp);
                            _ListPathGrouped.AddRange(lstTemp);
                        }
                        else if (lstTemp.Count >= 5)
                        {
                            int count = lstTemp.Count;
                            int currentIndex = 0;
                            while (count >= 5)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(5).ToList();
                                listListMatch.Add(lstThisGroup);
                                currentIndex += 5;
                                count -= 5;
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                            if (count < 5 && count > 1)
                            {
                                var lstThisGroup = lstTemp.Skip(currentIndex).Take(count).ToList();
                                listListMatch.Add(lstThisGroup);
                                _ListPathGrouped.AddRange(lstThisGroup);
                            }
                        }
                    }
                }
            }
            return listListMatch;
        }
        #endregion
        #region "check rule follow convention"
        /// <summary>
        /// check 2 string isvalid convention2 rule
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        private bool CheckRuleConvention1(string str1, string str2)
        {
            string fileName = Path.GetFileNameWithoutExtension(str1);
            string fileName1 = Path.GetFileNameWithoutExtension(str2);
            int count = fileName.Length < fileName1.Length ? fileName.Length : fileName1.Length;
            for (int i = 1; i <= count; i++)
            {
                if (fileName.Substring(0, i) != fileName1.Substring(0, i))
                {
                    string matchName = fileName.Substring(0, i - 1);
                    string outName = fileName.Substring(i - 1, fileName.Length - i + 1);
                    string outName1 = fileName1.Substring(i - 1, fileName1.Length - i + 1);
                    bool bCheckPrevChar = true;
                    if (i >= 2)
                    {
                        string prevChar = fileName.Substring(i - 2, 1);
                        if (prevChar != "_")
                        {
                            bCheckPrevChar = false;
                        }
                    }
                    if (bCheckPrevChar && !outName.Contains("_") && !outName1.Contains("_") && !outName.Any(char.IsDigit) && !outName1.Any(char.IsDigit))
                    {
                        return true;
                    }
                    break;
                }
                if (i == count && fileName1.Length >= i + 1)
                {
                    string prevChar = fileName1.Substring(i, 1);
                    string outName1 = fileName1.Substring(i + 1, fileName1.Length - i - 1);
                    if (prevChar == "_" && !String.IsNullOrEmpty(outName1) && !outName1.Contains("_") && !outName1.Any(char.IsDigit))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// check 2 string isvalid convention2 rule
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        private bool CheckRuleConvention2(string str1, string str2)
        {
            string fileName = Path.GetFileNameWithoutExtension(str1);
            string fileName1 = Path.GetFileNameWithoutExtension(str2);
            int count = fileName.Length < fileName1.Length ? fileName.Length : fileName1.Length;
            for (int i = 1; i <= count; i++)
            {
                if (fileName.Substring(0, i) != fileName1.Substring(0, i))
                {
                    string matchName = fileName.Substring(0, i - 1);
                    string outName = fileName.Substring(i - 1, fileName.Length - i + 1);
                    string outName1 = fileName1.Substring(i - 1, fileName1.Length - i + 1);
                    bool bCheckPrevChar = false;
                    if (i >= 2)
                    {
                        string prevChar = fileName.Substring(i - 2, 1);
                        if (prevChar == "-")
                        {
                            bCheckPrevChar = true;
                        }
                    }
                    if (bCheckPrevChar && !outName.Contains("-") && !outName1.Contains("-") && !outName.Any(char.IsDigit) && !outName1.Any(char.IsDigit))
                    {
                        return true;
                    }
                    break;
                }
                if (i == count && fileName1.Length >= i + 1)
                {
                    string prevChar = fileName1.Substring(i, 1);
                    string outName1 = fileName1.Substring(i + 1, fileName1.Length - i - 1);
                    if (prevChar == "-" && !String.IsNullOrEmpty(outName1) && !outName1.Contains("-") && !outName1.Any(char.IsDigit))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// check 2 string isvalid convention6 rule
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        private bool CheckRuleConvention6(string str1, string str2)
        {
            string fileName = Path.GetFileNameWithoutExtension(str1);
            string fileName1 = Path.GetFileNameWithoutExtension(str2);
            int count = fileName.Length < fileName1.Length ? fileName.Length : fileName1.Length;
            Int64 iTemp;
            for (int i = 1; i <= count; i++)
            {
                if (fileName.Substring(0, i) != fileName1.Substring(0, i))
                {
                    string matchName = fileName.Substring(0, i - 1);
                    string outName = fileName.Substring(i - 1, fileName.Length - i + 1);
                    string outName1 = fileName1.Substring(i - 1, fileName1.Length - i + 1);
                    bool bCheckPrevChar = true;
                    if (i >= 2)
                    {
                        string prevChar = fileName.Substring(i - 2, 1);
                        if (!(prevChar != "_" && prevChar != "-" && prevChar != " "))
                        {
                            bCheckPrevChar = false;
                        }
                    }
                    if (bCheckPrevChar && Int64.TryParse(outName, out iTemp) && iTemp > 0 && Int64.TryParse(outName1, out iTemp))
                    {
                        return true;
                    }
                    break;
                }
                if (i == count)
                {
                    string matchName = fileName.Substring(0, i - 1);
                    string outName = fileName.Substring(i - 1, fileName.Length - i + 1);
                    string outName1 = fileName1.Substring(i - 1, fileName1.Length - i + 1);
                    string prevChar = fileName.Substring(i - 2, 1);
                    if (prevChar != "_" && prevChar != "-" && prevChar != " " && Int64.TryParse(outName, out iTemp) && Int64.TryParse(outName1, out iTemp))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        #endregion
        /// <summary>
        /// move path in list path input to convention group (not yet check rule)
        /// </summary>
        private void MovePathToGroupConvention()
        {
            foreach (String sPath in this._ListPath)
            {
                Match match1 = regex1.Match(sPath);
                Match match2 = regex2.Match(sPath);
                if (match1.Success)
                {
                    _ListMatch1.Add(match1);
                }
                if (match2.Success)
                {
                    _ListMatch2.Add(match2);
                }
                Match match3 = regex3.Match(sPath);
                if (match3.Success)
                {
                    _ListMatch3.Add(match3);
                }
                Match match4 = regex4.Match(sPath);
                if (match4.Success)
                {
                    _ListMatch4.Add(match4);
                }
                Match match5 = regex5.Match(sPath);
                if (match5.Success)
                {
                    _ListMatch5.Add(match5);
                }
                Match match6 = regex6.Match(sPath);
                if (match6.Success)
                {
                    _ListMatch6.Add(match6);
                }
            }
        }
        #endregion
    }
}
