﻿using GroupDirectory.Combine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupDirectory
{
    public partial class Form1 : Form
    {
        #region "Declare"
        private List<String> _ListPathInput = new List<string>();
        #endregion
        #region "constructor"
        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(800, 600);
            this.tbInput.Text = "rootuploaded\\samplefolder\\1232_2342.jpg\n" +
                                "rootuploaded\\samplefolder\\1232_234234_1.jpg\n" +
                                "rootuploaded\\samplefolder\\1232_234234_2.bmp\n" +
                                "rootuploaded\\file-5.txt\n" +
                                "rootuploaded\\file-67.txt\n" +
                                "rootuploaded\\file-a.txt\n" +
                                "rootuploaded\\file1.txt\n" +
                                "rootuploaded\\file2.txt\n" +
                                "rootuploaded\\file5.txt\n" +
                                "rootuploaded\\filea.txt\n" +
                                "rootuploaded\\file_sample.txt\n" +
                                "rootuploaded\\file_sample_a.txt\n";
        }
        #endregion
        #region "event"
        private void btExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Pixelz Error");
            }
        }
        /// <summary>
        /// Event Combine directory path
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btCombine_Click(object sender, EventArgs e)
        {
            try
            {
                string input = tbInput.Text;
                rtbResult.Text = String.Empty;
                _ListPathInput = GetListPathInput(input);
                CombineHelper combineHelper = new CombineHelper(_ListPathInput);
                List<String> lstStringGroup = combineHelper.GetGroupDirectoryTree();
                rtbResult.Text = BuildTextToShow(lstStringGroup);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Pixelz Error");
            }
        }
        /// <summary>
        /// Build Text to show 
        /// </summary>
        /// <param name="lstStringGroup"></param>
        /// <returns></returns>
        private String BuildTextToShow(List<String> lstStringGroup)
        {
            int i = 0;
            StringBuilder sb = new StringBuilder();
            foreach (String itGroup in lstStringGroup)
            {
                i++;
                if (itGroup != lstStringGroup.Last())
                {
                    sb.Append("Group " + i + "\n");
                    sb.Append("\t" + itGroup);
                }
                else
                {
                    sb.Append("Cannot grouped \n");
                    sb.Append("\t" + itGroup);
                }
            }
            return sb.ToString();
        }

        #endregion
        #region "func/sub"
        /// <summary>
        /// BDBACH Get list path from input string
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        public List<String> GetListPathInput(String inputString)
        {
            List<String> lstPathResult = new List<string>();
            if (!string.IsNullOrEmpty(inputString))
            {
                String[] pathArray = inputString.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string sPath in pathArray)
                {
                    string path = sPath.Trim();
                    //check after split path empty or null AND path don't exists in list Path result
                    if (!string.IsNullOrEmpty(path) && !lstPathResult.Contains(path))
                    {
                        lstPathResult.Add(path);
                    }
                }
            }
            return lstPathResult;
        }
        #endregion
    }
}
