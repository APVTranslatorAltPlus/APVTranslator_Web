﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupDirectory
{
    public static class Constant
    {
        //convention 1
        public static String regexConvention1 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/+){0,})([a-zA-Z_0-9!#-@#$%^&()]+)?(_+[a-zA-Z]+)?(\.+[a-zA-Z_0-9]+)$";
        //convention 2
        public static String regexConvention2 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/){0,})([a-zA-Z_0-9!#-@#$%^&()]+)?(-+[a-zA-Z]+)?(\.+[a-zA-Z_0-9]+)$";
        //convention 3
        public static String regexConvention3 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/){0,})([a-zA-Z_0-9!#-@#$%^&()]+)?(_+[0-9]+)(\.+[a-zA-Z_0-9]+)$";
        //convention 4
        public static String regexConvention4 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/){0,})([a-zA-Z_0-9!#-@#$%^&()]+)?(-+[0-9]+)(\.+[a-zA-Z_0-9]+)$";
        //convention 5
        public static String regexConvention5 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/){0,})([a-zA-Z_0-9!#-@#$%^&()]+)?(\s+[0-9]+)(\.+[a-zA-Z_0-9]+)$";
        //convention 6
        public static String regexConvention6 = @"^((rootuploaded(\\|\/))([a-zA-Z_0-9!#-@#$%^&()]+\\|\/){0,})([a-zA-Z_!#-@#$%^&()]+)?([0-9]+)(\.+[a-zA-Z_0-9]+)$";

    }
}
